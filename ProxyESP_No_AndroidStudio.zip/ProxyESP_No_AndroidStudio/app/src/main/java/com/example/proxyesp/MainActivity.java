package com.example.proxyesp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private int red = Color.rgb(238, 54, 70);
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(13, 14, 19));
        getWindow().setNavigationBarColor(Color.rgb(13, 14, 19));
        build();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(13, 14, 19));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 28, 22, 28);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("PROXY ESP", 27, Color.WHITE, true);
        root.addView(brand);
        TextView sub = text("VISUAL DEMO  •  STANDALONE APP", 11, red, true);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.topMargin = 5; sp.bottomMargin = 22; root.addView(sub, sp);

        LinearLayout preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setGravity(Gravity.CENTER);
        preview.setPadding(16, 20, 16, 20);
        preview.setBackground(bg(Color.rgb(27, 29, 38), 22));
        TextView label = text("DEMO PREVIEW", 12, Color.LTGRAY, true);
        preview.addView(label);
        TextView figure = text("┌─────────────┐\n│     ●       │\n│   / | \\     │\n│    / \\      │\n└─────────────┘", 22, red, true);
        figure.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = 12; preview.addView(figure, fp);
        TextView note = text("Макет интерфейса — не отображает игроков", 11, Color.GRAY, false);
        preview.addView(note);
        root.addView(preview);

        section("ВИЗУАЛЬНЫЕ ЭФФЕКТЫ");
        addSwitch("ESP Overlay", true);
        addSwitch("Box", true);
        addSwitch("Lines", false);
        addSwitch("Names", true);
        addSwitch("Distance", false);

        section("ОФОРМЛЕНИЕ");
        addSwitch("Красная тема", true);
        TextView disclaimer = text("Это автономная демонстрация интерфейса. Приложение не подключается к Standoff 2, не читает игровые данные и не влияет на игровой процесс.", 12, Color.GRAY, false);
        disclaimer.setPadding(14, 16, 14, 16);
        disclaimer.setBackground(bg(Color.rgb(24, 25, 32), 16));
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = 20; root.addView(disclaimer, dp);
        TextView footer = text("PROXY ESP  •  VERSION 1.0", 10, Color.DKGRAY, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = 22; root.addView(footer, tp);
    }

    private void section(String title) {
        TextView t = text(title, 12, Color.rgb(238, 54, 70), true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 24; p.bottomMargin = 8; root.addView(t, p);
    }

    private void addSwitch(String title, boolean checked) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(14, 7, 10, 7);
        row.setBackground(bg(Color.rgb(27, 29, 38), 14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = 8; root.addView(row, p);
        TextView name = text(title, 15, Color.WHITE, false);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(checked);
        sw.setButtonTintList(null);
        row.addView(sw);
    }
}
